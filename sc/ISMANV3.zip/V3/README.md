# IsmanV3
## Bot Whatsapp

<p align="center">
	<img src="https://telegra.ph/file/c7678f1c322c7bd014fce.jpg" style="margin-left: auto;margin-right: auto;display: block;">
</p>

## Github
```bash
 > https://github.com/isman-IM
```

## Heroku Buildpack

Click the deploy icon below !

[![Deploy](https://www.herokucdn.com/deploy/button.svg)](https://heroku.com/deploy?template=https://github.com/isman-IM/IsmanV3)

```bash
 > heroku/nodejs
 > https://github.com/jonathanong/heroku-buildpack-ffmpeg-latest
 > https://github.com/clhuang/heroku-buildpack-webp-binaries.git
```

## TERMUX USER
```bash
> pkg update && pkg upgrade
> pkg install libwebp
> pkg install yarn
> pkg install git
> pkg install nodejs
> pkg install ffmpeg
> termux-setup-storage
> git clone https://github.com/isman-IM/IsmanV3.git
> cd IsmanV3
> yarn install
> npm start
```

## RDP/VPS USER
```bash 
> git clone https://github.com/isman-IM/IsmanV3.git
> cd IsmanV3
> npm install
> npm start
```

# My Sosial
- [Group Info Update](https://chat.whatsapp.com/I9lQWN2EoUU3nLTC0TriJO)
- [Whatsapp ](https://wa.me/6282237949722)
